import { ShoppingCart, Search, Menu } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export default function Header({ cartCount, onCartClick }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <button className="lg:hidden text-white/80 hover:text-white transition-colors">
              <Menu size={24} />
            </button>
            <h1 className="text-2xl font-bold text-white tracking-tight">LUXE</h1>
            <nav className="hidden lg:flex items-center gap-6">
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">Electronics</a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">Fashion</a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">Cosmetics</a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">Instruments</a>
              <a href="#" className="text-sm text-white/60 hover:text-white transition-colors">Gadgets</a>
              <a href="#about" className="text-sm text-white/60 hover:text-white transition-colors">About</a>
              <a href="#contact" className="text-sm text-white/60 hover:text-white transition-colors">Contact</a>
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <button className="text-white/60 hover:text-white transition-colors">
              <Search size={20} />
            </button>
            <button
              onClick={onCartClick}
              className="relative text-white/60 hover:text-white transition-colors"
            >
              <ShoppingCart size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-white text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
