export default function About() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-white/5">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-8 text-center">
          About LUXE
        </h2>
        <div className="space-y-6 text-lg text-white/70">
          <p>
            Welcome to LUXE, your premier destination for luxury online shopping. We curate the finest selection of electronics, fashion, cosmetics, musical instruments, and cutting-edge gadgets from top brands around the world.
          </p>
          <p>
            Founded with a passion for excellence, LUXE is committed to delivering an unparalleled shopping experience. We carefully select each product to ensure it meets our high standards of quality, style, and innovation.
          </p>
          <p>
            Our mission is to make luxury accessible, combining premium products with exceptional service, competitive prices, and fast, reliable shipping. Whether you're searching for the latest tech gadget, a statement fashion piece, or professional-grade musical instruments, LUXE is your trusted partner in premium online shopping.
          </p>
        </div>
      </div>
    </section>
  );
}
