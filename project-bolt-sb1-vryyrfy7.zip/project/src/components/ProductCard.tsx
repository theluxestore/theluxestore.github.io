import { ShoppingCart } from 'lucide-react';
import { Product } from '../lib/supabase';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <div className="group relative bg-white/5 backdrop-blur-sm rounded-lg overflow-hidden border border-white/10 hover:border-white/30 transition-all duration-300 hover:scale-[1.02]">
      <div className="aspect-square overflow-hidden bg-black/20">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      <div className="p-5">
        <h3 className="text-white font-semibold text-lg mb-2 line-clamp-1">
          {product.name}
        </h3>
        <p className="text-white/60 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between">
          <span className="text-white text-xl font-bold">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={() => onAddToCart(product)}
            disabled={product.stock === 0}
            className="bg-white text-black px-4 py-2 rounded-md font-medium text-sm hover:bg-white/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <ShoppingCart size={16} />
            Add
          </button>
        </div>

        {product.stock === 0 && (
          <div className="mt-2 text-red-400 text-xs">Out of stock</div>
        )}
        {product.stock > 0 && product.stock < 10 && (
          <div className="mt-2 text-yellow-400 text-xs">Only {product.stock} left</div>
        )}
      </div>

      {product.featured && (
        <div className="absolute top-3 left-3 bg-white text-black px-3 py-1 rounded-full text-xs font-bold">
          FEATURED
        </div>
      )}
    </div>
  );
}
