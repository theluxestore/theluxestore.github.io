export default function Hero() {
  return (
    <div className="relative h-[500px] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-black to-slate-900"></div>

      <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1600')] bg-cover bg-center opacity-20"></div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
          Premium Online Shopping at LUXE
        </h1>
        <p className="text-xl md:text-2xl text-white/70 mb-8">
          Shop Top Brands in Electronics, Fashion, Cosmetics, Musical Instruments & Gadgets - Best Deals with Fast Shipping
        </p>
        <button className="bg-white text-black px-8 py-4 rounded-md font-semibold text-lg hover:bg-white/90 transition-colors">
          Shop Now - Free Shipping
        </button>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent"></div>
    </div>
  );
}
