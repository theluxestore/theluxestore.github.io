/*
  # Create Online Shopping Store Schema

  1. New Tables
    - `categories`
      - `id` (uuid, primary key)
      - `name` (text, category name)
      - `slug` (text, URL-friendly identifier)
      - `description` (text, category description)
      - `created_at` (timestamptz, creation timestamp)
    
    - `products`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key to categories)
      - `name` (text, product name)
      - `description` (text, product description)
      - `price` (decimal, product price)
      - `image_url` (text, product image URL)
      - `stock` (integer, available quantity)
      - `featured` (boolean, whether product is featured)
      - `created_at` (timestamptz, creation timestamp)
    
    - `cart_items`
      - `id` (uuid, primary key)
      - `user_id` (uuid, reference to auth.users)
      - `product_id` (uuid, foreign key to products)
      - `quantity` (integer, item quantity)
      - `created_at` (timestamptz, creation timestamp)
  
  2. Security
    - Enable RLS on all tables
    - Categories and products are publicly readable
    - Cart items are only accessible to the owner
  
  3. Indexes
    - Add index on products.category_id for faster queries
    - Add index on cart_items.user_id for faster lookups
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  price decimal(10, 2) NOT NULL,
  image_url text NOT NULL,
  stock integer DEFAULT 0,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  quantity integer DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_id);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

-- Categories policies (public read)
CREATE POLICY "Categories are publicly readable"
  ON categories FOR SELECT
  USING (true);

-- Products policies (public read)
CREATE POLICY "Products are publicly readable"
  ON products FOR SELECT
  USING (true);

-- Cart items policies (user can only access their own cart)
CREATE POLICY "Users can view own cart items"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert sample categories
INSERT INTO categories (name, slug, description) VALUES
  ('Electronics', 'electronics', 'Latest tech gadgets and devices'),
  ('Fashion', 'fashion', 'Trendy clothing and accessories'),
  ('Home & Living', 'home-living', 'Furniture and home decor'),
  ('Sports', 'sports', 'Sports equipment and activewear')
ON CONFLICT (slug) DO NOTHING;

-- Insert sample products
INSERT INTO products (category_id, name, description, price, image_url, stock, featured) VALUES
  (
    (SELECT id FROM categories WHERE slug = 'electronics'),
    'Premium Wireless Headphones',
    'High-fidelity sound with active noise cancellation',
    299.99,
    'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=800',
    50,
    true
  ),
  (
    (SELECT id FROM categories WHERE slug = 'electronics'),
    'Smart Watch Pro',
    'Advanced fitness tracking and notifications',
    399.99,
    'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=800',
    30,
    true
  ),
  (
    (SELECT id FROM categories WHERE slug = 'fashion'),
    'Leather Jacket',
    'Premium genuine leather with modern fit',
    249.99,
    'https://images.pexels.com/photos/1124468/pexels-photo-1124468.jpeg?auto=compress&cs=tinysrgb&w=800',
    25,
    true
  ),
  (
    (SELECT id FROM categories WHERE slug = 'fashion'),
    'Designer Sunglasses',
    'UV protection with polarized lenses',
    179.99,
    'https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=800',
    40,
    false
  ),
  (
    (SELECT id FROM categories WHERE slug = 'home-living'),
    'Modern Table Lamp',
    'Minimalist design with adjustable brightness',
    89.99,
    'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=800',
    60,
    false
  ),
  (
    (SELECT id FROM categories WHERE slug = 'sports'),
    'Yoga Mat Pro',
    'Non-slip surface with extra cushioning',
    49.99,
    'https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=800',
    100,
    false
  )
ON CONFLICT DO NOTHING;